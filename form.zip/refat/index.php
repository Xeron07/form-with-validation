<?php
  header("location:form.php");
?>