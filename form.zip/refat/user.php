<!DOCTYPE html>

<html>
<head>
	<title>Home</title>

 <script type="text/javascript" src="sweetalert.min.js">import swal from 'sweetalert';
    </script>

</head>
<body>

</body>

<?php 
    echo'<script>setTimeout(function() {swal("Welcome!","Login Successful","success") }, 200);</script>';
?>

</html>

